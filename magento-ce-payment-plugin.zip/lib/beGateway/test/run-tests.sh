#!/bin/bash

`which php` -f beGateway.php
