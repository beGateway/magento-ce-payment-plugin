<?php
namespace BeGateway;

class Capture extends ChildTransaction {
}
?>
