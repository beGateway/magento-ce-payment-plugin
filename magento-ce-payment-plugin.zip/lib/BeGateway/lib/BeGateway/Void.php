<?php
namespace BeGateway;

class Void extends ChildTransaction {
}
?>
