<?php
namespace BeGateway;

class Payment extends Authorization {
}
?>
